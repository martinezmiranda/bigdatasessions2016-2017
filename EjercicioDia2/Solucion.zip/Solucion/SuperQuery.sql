CREATE TABLE LeagueOfLegends.DashboardResults AS
SELECT 
c.Name, 
100 * SUM(CASE WHEN s.Winner THEN 1.0 ELSE 0.0 END) / COUNT(*) AS WinRate, 
AVG(s.Kills) AS AvgKills, 
MAX(s.Kills) AS MaxKills, 
AVG(s.Deaths) AS AvgDeaths,
MAX(s.Deaths) AS MaxDeaths,
AVG(s.Assists) AS AvgAssists,
AVG(s.TotalDamageDealt) AS AvgDamageDealt,
AVG(s.TotalDamageTaken) AS AvgDamageTaken,
AVG(s.TotalHeal) AS AvgHealing,
AVG(s.LargestKillingSpree) AS AvgKillingSpree,
MAX(s.LargestKillingSpree) AS MaxKillingSpree,
AVG(s.GoldEarned) AS AvgGold,
(100.0 * COUNT(*) / MAX(m.TotalMatches)) AS PickRate
FROM LeagueOfLegends.Stats s
INNER JOIN LeagueOfLegends.Participants p
ON s.MatchID = p.MatchID AND s.ParticipantID = p.ParticipantID
INNER JOIN LeagueOfLegends.Champions c 
ON c.ID = p.ChampionID
CROSS JOIN (SELECT COUNT(DISTINCT MatchID) AS TotalMatches FROM LeagueOfLegends.Participants) m
GROUP BY c.Name
ORDER BY c.Name DESC;
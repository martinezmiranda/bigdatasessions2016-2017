﻿namespace AvroFileGenerator
{
    using System.Runtime.Serialization;

    [DataContract(Name = "Awards", Namespace = "Baseball")]
    internal class Award
    {
        [DataMember(Name = "playerID")]
        public string PlayerID { get; set; }

        [DataMember(Name = "awardID")]
        public string AwardID { get; set; }

        [DataMember(Name = "yearID")]
        public int YearID { get; set; }

        [DataMember(Name = "lgID")]
        public string LGID { get; set; }

        [DataMember(Name = "tie", IsRequired = false)]
        public string Tie { get; set; }

        [DataMember(Name = "notes", IsRequired = false)]
        public string Notes { get; set; }
    }
}

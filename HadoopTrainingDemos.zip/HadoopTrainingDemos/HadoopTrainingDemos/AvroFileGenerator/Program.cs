﻿namespace AvroFileGenerator
{
    using Microsoft.Hadoop.Avro.Container;
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class Program
    {
        static void Main(string[] args)
        {
            // Get a list of Award objects
            List<Award> awards = GetData();

            // Serialize Award objects to a file in Avro format
            string fileName = "awards.avro";
            string filePath = new DirectoryInfo(".") + @"\" + fileName;

            using (var dataStream = new FileStream(filePath, FileMode.Create))
            {
                using (var avroWriter = AvroContainer.CreateWriter<Award>(dataStream, Codec.Null))
                {
                    using (var seqWriter = new SequentialWriter<Award>(avroWriter, 24))
                    {
                        awards.ForEach(seqWriter.Write);
                    }
                }

                dataStream.Close();

                Console.WriteLine("AVRO file generated");
                Console.ReadLine();
            }
        }

        static List<Award> GetData()
        {
            List<Award> awards = new List<Award>();

            awards.Add(new Award() { PlayerID = "bondto01", AwardID = "Most Valuable BI Developer", YearID = 1992, LGID = "AL", Notes = string.Empty, Tie = string.Empty });

            return awards;
        }
    }
}
﻿namespace WebHDFSClient
{
    using Microsoft.Hadoop.WebHDFS;
    using System;

    public class Program
    {
        static void Main(string[] args)
        {
            string sourceFile = "stats.txt";
            string destinationPath = "/user/hive/warehouse/stats";
            string destinationFile = "stats.txt";

            //connect to hadoop cluster
            var clusterUri = new Uri("http://mstrainingmadrid-mn0.northeurope.cloudapp.azure.com:50070");
            string username = "hdfs";
            var webClient = new WebHDFSClient(clusterUri, username);
            
            //drop destination directory (if exists)
            webClient.DeleteDirectory(destinationPath, true);

            //create destination directory
            webClient.CreateDirectory(destinationPath).Wait();

            //load file to destination directory
            webClient.CreateFile(sourceFile, destinationPath + "/" + destinationFile).Wait();

            //keep command window open until user presses enter
            Console.ReadLine();
        }
    }
}

﻿namespace SensorProducer
{
    public class Sensor
    {
        public string Name { get; set; }

        public double Value { get; set; }
    }
}

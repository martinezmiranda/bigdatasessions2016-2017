﻿namespace SensorProducer
{
    using Microsoft.ServiceBus.Messaging;
    using Newtonsoft.Json;
    using System;
    using System.Configuration;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    public class Program
    {
        static Random _next = new Random(212323);

        static void Main(string[] args)
        {
            var tokenSource = new CancellationTokenSource();

            var task = new TaskFactory()
                .StartNew(() => Produce(tokenSource.Token));

            Console.WriteLine("Producing data... press any key to stop!");
            Console.ReadLine();

            tokenSource.Cancel();
            task.Wait();
        }

        static void Produce(CancellationToken cancellationToken)
        {
            var eventHubPath = ConfigurationManager.AppSettings["EventHubPath"];
            var hub = EventHubClient.Create(eventHubPath);

            while (true)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                var sensor = new Sensor()
                {
                    Value = _next.NextDouble(),
                    Name = ((DateTime.UtcNow.Second & 1) == 1) ? "Sensor-A" : "Sensor-B"
                };

                hub.SendAsync(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(sensor)))).Wait();
            }
        }
    }
}

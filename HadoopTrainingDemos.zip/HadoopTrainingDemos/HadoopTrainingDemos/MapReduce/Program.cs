﻿namespace MapReduce
{
    using System;

    public class Program
    {
        static void Main(string[] args)
        {
            WhatsappMR mapreduce = new WhatsappMR();
            mapreduce.MapReduce(@"test.txt");
            var res = mapreduce.LineStore;
            Console.WriteLine(string.Format("Me-->{0}\nHe-->{1}", res["me"], res["he"]));

            Console.ReadLine();
        }
    }
}

﻿namespace MapReduce
{
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    public class WhatsappMR
    {
        private static ConcurrentBag<string> _lineBag = new ConcurrentBag<string>();
        //here we store the "pairs" [he-->1] and [me-->1]
        private BlockingCollection<string> _lineChunks = new BlockingCollection<string>(_lineBag);

        //here we will store the final result
        public ConcurrentDictionary<string, int> LineStore = new ConcurrentDictionary<string, int>();
        private static int _chunckSize = 1000;

        /// <summary>
        /// Splitting function
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public IEnumerable<IEnumerable<string>> GenerateChunks(string filePath)
        {
                var lines = System.IO.File.ReadAllLines(filePath).ToList();

                for (int i = 0; i < lines.Count; i += _chunckSize)
                {
                    List<string> partial = new List<string>();
                    if (i + _chunckSize > lines.Count)
                    {
                        partial = lines.GetRange(i, (lines.Count) - (i) );
                        yield return partial;
                    }
                    else
                    {
                        partial = lines.GetRange( i, _chunckSize);
                        yield return partial;

                    }
                }

        }

        /// <summary>
        /// Map function. It generates "pairs" key value being the key "me" or "he" and the value is always 1
        /// </summary>
        /// <param name="fileText"></param>
        public void Map(string fileText)
        {
            Parallel.ForEach(GenerateChunks(fileText), lineBlock =>
            {

                foreach (string line in lineBlock)
                {
                    if (line.Contains("; he:"))
                        _lineChunks.Add("he");
                    else if (line.Contains("; ME:"))
                        _lineChunks.Add("me");
                }
            });

            _lineChunks.CompleteAdding();
        }

        

        /// <summary>
        /// It iterates over the and increment the key by one
        /// </summary>
        public void Reduce()
        {
            Parallel.ForEach(_lineChunks.GetConsumingEnumerable(), line =>
            {   
                LineStore.AddOrUpdate(line, 1, (key, oldValue) => Interlocked.Increment(ref oldValue));
            });
        }

        public void MapReduce(string fileText)
        {   

            System.Threading.ThreadPool.QueueUserWorkItem(delegate(object state)
            {
                Map(fileText);
            });

            Reduce();
        }

    }
}
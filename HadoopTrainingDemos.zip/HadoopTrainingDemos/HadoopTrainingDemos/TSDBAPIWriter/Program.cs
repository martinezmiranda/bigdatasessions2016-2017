﻿namespace TSDBAPIWriter
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Net;
    using System.Threading;

    class Program
    {
        private static string serverURI = "http://mstrainingmadrid-mn0.northeurope.cloudapp.azure.com:4242/api/put";
        private static string baseJSONQuery = "[\"metric\": \"{0}\",\"timestamp\": {1},\"value\": {2},\"tags\": [\"city\": \"{3}\"]]";
        private static Random rnd = new Random();

        static void Main(string[] args)
        {
            serverURI = ConfigurationManager.AppSettings["ServerUri"];

            var values = 0;

            while (true)
            {
                var madridMetricValue = GenerateMetricValue(DateTime.UtcNow, "Temperature", -10, 45, "Madrid");
                var oviedoMetricValue = GenerateMetricValue(DateTime.UtcNow, "Temperature", -3, 30, "Oviedo");

                SendMetricValue(madridMetricValue);
                SendMetricValue(oviedoMetricValue);

                Console.WriteLine("Created metric value {0}", ++values);
                Thread.Sleep(TimeSpan.FromSeconds(5));
            }
        }

        public static string GenerateMetricValue(DateTime timestamp, string name, int min, int max, string tag)
        {
            int value = rnd.Next(min, max);
            var unixTimestamp = ToUnixTimeStamp(timestamp);

            var json = string.Format(baseJSONQuery, name, unixTimestamp, value, tag);
            json = json.Replace('[', '{');
            json = json.Replace(']', '}');

            return json;
        }

        public static bool SendMetricValue(string json)
        {
            var uri = new Uri(serverURI);
            var spm = ServicePointManager.FindServicePoint(uri);
            spm.Expect100Continue = false;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            httpWebRequest.SendChunked = false;
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var responseText = streamReader.ReadToEnd();

                return true;
            }
        }

        public static int ToUnixTimeStamp(DateTime dateTime)
        {
            return (int)Math.Round((dateTime.Subtract(new DateTime(1970, 1, 1))).TotalSeconds);
        }
    }
}
